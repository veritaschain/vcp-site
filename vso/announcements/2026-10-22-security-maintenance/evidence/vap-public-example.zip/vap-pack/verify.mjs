import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

export const sha = data => crypto.createHash('sha256').update(data).digest();
export const hex = data => sha(data).toString('hex');
// RFC 8785 for this mapping's JSON subset: strings, booleans, null, arrays,
// and objects. Numbers are forbidden; keys use ECMAScript UTF-16 sorting.
export function canonical(value) {
  if (value === null || typeof value === 'boolean') return JSON.stringify(value);
  if (typeof value === 'string') {
    if (!value.isWellFormed()) throw Error('Invalid Unicode');
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
  if (typeof value === 'object') return '{' + Object.keys(value).sort().map(k => canonical(k) + ':' + canonical(value[k])).join(',') + '}';
  throw Error('Unsupported JSON value; all numbers must be strings');
}
export function projection(event) {
  const e = structuredClone(event);
  delete e.security.event_hash;
  delete e.security.signature;
  return e;
}
export function merkle(leaves) {
  if (!leaves.length) return sha(Buffer.alloc(0));
  if (leaves.length === 1) return leaves[0];
  const k = 2 ** Math.floor(Math.log2(leaves.length - 1));
  return sha(Buffer.concat([Buffer.from([1]), merkle(leaves.slice(0, k)), merkle(leaves.slice(k))]));
}
export function proof(leaves, index) {
  if (leaves.length === 1) return [];
  const k = 2 ** Math.floor(Math.log2(leaves.length - 1));
  return index < k
    ? [...proof(leaves.slice(0, k), index), { side: 'right', hash: merkle(leaves.slice(k)).toString('hex') }]
    : [...proof(leaves.slice(k), index - k), { side: 'left', hash: merkle(leaves.slice(0, k)).toString('hex') }];
}
const requireThat = (ok, message) => { if (!ok) throw Error(message); };

export function verifyPack(root, externalAnchor = true) {
  const read = rel => fs.readFileSync(path.join(root, rel));
  const json = rel => JSON.parse(read(rel));
  const policy = json('policy.json');
  const pub = crypto.createPublicKey(read('session-public-key.pem'));
  const signer = 'sha256:' + hex(pub.export({ format: 'der', type: 'spki' }));
  const events = read('events.jsonl').toString().trim().split('\n').map(JSON.parse);
  const manifest = json('evidence-manifest.json');
  const commitment = json('anchor/commitment.json');
  const c = structuredClone(commitment);
  const signature = c.security.signature;
  delete c.security.signature;
  requireThat(crypto.verify(null, sha(canonical(c)), pub, Buffer.from(signature, 'base64')), 'Invalid batch signature');
  requireThat(commitment.policy_sha256 === hex(read('policy.json')), 'Policy altered');
  requireThat(commitment.evidence_manifest_sha256 === hex(read('evidence-manifest.json')), 'Evidence manifest altered');
  requireThat(commitment.verifier_sha256 === hex(read('verify.mjs')), 'Verifier altered');
  requireThat(commitment.security.signer_id === signer, 'Batch signer mismatch');
  requireThat(commitment.batch.event_count === String(events.length), 'Event omission/count mismatch');
  requireThat(commitment.batch.first_event_id === events[0].header.event_id, 'First event mismatch');
  requireThat(commitment.batch.last_event_id === events.at(-1).header.event_id, 'Last event mismatch');
  requireThat(commitment.batch.policy_id === policy.policy_id, 'Batch policy mismatch');
  const ids = new Set();
  let previous = '0'.repeat(64);
  for (const e of events) {
    requireThat(e.vap_version === '1.2' && e.profile.id === policy.profile_id, 'Event mapping mismatch');
    requireThat(/^[0-9a-f]{8}-[0-9a-f]{4}-7[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(e.header.event_id), 'Invalid UUIDv7');
    requireThat(!ids.has(e.header.event_id), 'Duplicate event'); ids.add(e.header.event_id);
    requireThat(e.security.prev_hash === previous, 'Hash-chain mismatch');
    requireThat(e.security.hash_algo === 'SHA256' && e.security.sign_algo === 'ED25519', 'Unexpected algorithms');
    requireThat(e.security.signer_id === signer, 'Event signer mismatch');
    requireThat(e.policy.policy_id === policy.policy_id && e.policy.policy_sha256 === commitment.policy_sha256, 'Event policy mismatch');
    requireThat(e.security.anchor_reference === commitment.anchor_record_id, 'Anchor reference mismatch');
    const digest = sha(canonical(projection(e)));
    requireThat(digest.toString('hex') === e.security.event_hash, 'Event hash mismatch');
    requireThat(crypto.verify(null, digest, pub, Buffer.from(e.security.signature, 'base64')), 'Invalid event signature');
    previous = e.security.event_hash;
  }
  const leaves = events.map(e => sha(Buffer.concat([Buffer.from([0]), Buffer.from(canonical(e))])));
  const rootHash = merkle(leaves).toString('hex');
  requireThat(rootHash === commitment.batch.merkle_root, 'Merkle root mismatch');
  const paths = json('merkle-proofs.json');
  requireThat(paths.length === events.length, 'Missing audit paths');
  paths.forEach((p, i) => {
    requireThat(p.event_id === events[i].header.event_id && p.index === String(i), 'Proof event/index mismatch');
    requireThat(canonical(p.path) === canonical(proof(leaves, i)), 'Invalid RFC 6962 audit path');
  });
  for (const file of manifest.files) {
    requireThat(!path.isAbsolute(file.path) && !file.path.split('/').includes('..'), 'Unsafe evidence path');
    requireThat(hex(read(file.path)) === file.sha256, 'Evidence altered: ' + file.path);
  }
  const evidence = new Map(manifest.files.map(file => [file.path, file.sha256]));
  for (const event of events) {
    for (const ref of event.provenance.input.evidence) {
      requireThat(evidence.get(ref.path) === ref.sha256, 'Evidence reference mismatch');
    }
  }
  if (externalAnchor) {
    const record = json('anchor/anchor-record.json');
    const ar = structuredClone(record); const sig = ar.security.signature; delete ar.security.signature;
    requireThat(crypto.verify(null, sha(canonical(ar)), pub, Buffer.from(sig, 'base64')), 'Invalid AnchorRecord signature');
    requireThat(record.security.signer_id === signer, 'AnchorRecord signer mismatch');
    requireThat(record.anchor_record_id === commitment.anchor_record_id, 'AnchorRecord identity mismatch');
    requireThat(canonical(record.batch) === canonical(commitment.batch), 'AnchorRecord batch mismatch');
    requireThat(record.anchor_target.proof.commitment_sha256 === hex(read('anchor/commitment.json')), 'Anchor commitment mismatch');
    requireThat(record.anchor_target.proof.response_sha256 === hex(read('anchor/response.tsr')), 'Timestamp response altered');
    requireThat(hex(read('anchor/cacert.pem')) === policy.tsa.ca_file_sha256, 'TSA trust anchor changed');
    requireThat(hex(read('anchor/tsa.crt')) === policy.tsa.signer_certificate_file_sha256, 'TSA certificate changed');
    const openssl = process.env.OPENSSL || 'openssl';
    execFileSync(openssl, ['ts', '-verify', '-in', 'anchor/response.tsr', '-data', 'anchor/commitment.json', '-CAfile', 'anchor/cacert.pem', '-untrusted', 'anchor/tsa.crt'], { cwd: root, stdio: 'pipe' });
    execFileSync(openssl, ['ts', '-verify', '-in', 'anchor/response.tsr', '-queryfile', 'anchor/request.tsq', '-CAfile', 'anchor/cacert.pem', '-untrusted', 'anchor/tsa.crt'], { cwd: root, stdio: 'pipe' });
  }
  return { valid: true, events: events.length, evidence_files: manifest.files.length, merkle_root: rootHash, external_anchor_verified: externalAnchor, conformance_claimed: false };
}
if (process.argv[1] && fs.realpathSync(process.argv[1]) === fs.realpathSync(fileURLToPath(import.meta.url))) {
  try { console.log(JSON.stringify(verifyPack(path.dirname(fileURLToPath(import.meta.url)), !process.argv.includes('--integrity-only')), null, 2)); }
  catch (e) { console.error('VERIFICATION FAILED: ' + e.message); process.exitCode = 1; }
}
