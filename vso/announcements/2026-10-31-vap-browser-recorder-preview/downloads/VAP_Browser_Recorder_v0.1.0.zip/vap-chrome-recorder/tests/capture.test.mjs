import test from 'node:test';
import assert from 'node:assert/strict';
import {captureSelection} from '../extension/lib/capture.mjs';
function page({protocol='https:',text='合成テキスト',collapsed=false,input=false,rangeCount=1}={}){
  globalThis.location={protocol,origin:'https://fixture.test'};
  const endpoint={nodeType:3,parentElement:{closest:()=>input?{}:null}};
  globalThis.window={getSelection:()=>({isCollapsed:collapsed,rangeCount,getRangeAt:()=>({startContainer:endpoint,endContainer:endpoint}),toString:()=>text})};
}
test('selected DOM capture returns only text and origin, with no page URL path',()=>{page();assert.deepEqual(captureSelection(),{origin:'https://fixture.test',text:'合成テキスト'});});
test('capture rejects missing selection, multiple ranges and edit fields',()=>{for(const opts of [{collapsed:true},{rangeCount:0},{rangeCount:2},{input:true},{text:'  '}]){page(opts);assert.throws(captureSelection);}});
test('capture rejects protected protocols and excessive UTF8 bytes',()=>{for(const opts of [{protocol:'chrome:'},{protocol:'file:'},{text:'あ'.repeat(12000)}]){page(opts);assert.throws(captureSelection);}});
